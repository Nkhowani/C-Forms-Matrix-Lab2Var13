﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2Var13
{
    public partial class Form1 : Form
    {
        Matrix A = null;
        Matrix B = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void msize_ValueChanged(object sender, EventArgs e)
        {
            //Строем матриц А
            int k = Convert.ToInt32(msize.Value);

            A = Matrix.getA(k);
            A.output(table1);

            //int kForB = 1;

            //
            B = Matrix.getB(A, 0);
            B.output(table2);
        }
    }
}
