﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Lab2Var13
{
    public class Matrix
    {
        //Поля
        double[,] Array = null;

        //Свойство
        public int N
        {
            get
            {
                if (Array == null)
                    return 0;
                else
                    return Array.GetLength(0);
            }
        }
        //Конструктя
        public Matrix(int k = 2)
        {
            k = Math.Max(2, k);
            Array = new double[k, k];
        }
        //
        public void random(int a = 0, int b = 10)
        {
            Random R = new Random();
            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                    Array[i, j] = R.Next(a, b) + R.NextDouble();
        }
        //Метод для ввод матриц на форму
        public void output(DataGridView table)
        {
            //Настроение таблицу над матрицу
            table.RowCount = table.ColumnCount = N;

            //Выводим матрицу в ячеке таблицу
            for (int i = 0; i < N; i++)
            {
                table.Rows[i].HeaderCell.Value = $"{i}";
                table.Columns[i].HeaderCell.Value = $"{i}";

                //Выделяем элементы на главный диагонал
                for (int j = 0; j < N; j++)
                {
                    if (i == j)
                        table.Rows[i].Cells[j].Style.ForeColor = Color.Aqua;
                    else
                        table.Rows[i].Cells[j].Style.BackColor = Color.Gray;
                    table.Rows[i].Cells[j].Value = $"{Array[i, j]:F0}";
                }
            }
            //Настроениетшрину и высоту таблицу
            table.AutoResizeColumns();
            table.AutoResizeRows();
        }
        public static void Clear(DataGridView table)
        {
            if (table == null)
                return;
            for (int i = 0; i < table.RowCount; i++)
                for (int j = 0; j < table.ColumnCount; i++)
                    table.Rows[i].Cells[j].Value = "";
        }
        //Метод для транспонирование матриц
        public static Matrix transform(Matrix A)
        {
            if (A == null || A.N == 0)
                return new Matrix(2);
            Matrix C = new Matrix(A.N);
            for (int i = 0; i < C.N; i++)
                for (int j = 0; j < C.N; j++)
                    C.Array[i, j] = A.Array[j, i];
            return C;
        }
        //Сохранение матриц заполнеии на форме
        public void save(DataGridView table)
        {
            if (Array == null || N == 0 || table == null)
                return;
            for (int i = 0; i < N; i++)
                for (int j = 0; j < N; j++)
                    if (Double.TryParse(table.Rows[i].Cells[j].Value.ToString(), out Array[i, j])) ;
                    else Array[i, j] = 0.0;
        }
        //реаизатор индексатор
        public double this[int i, int j]
        {
            set
            {
                if (i >= 0 && j >= 0 && i < N && j < N)
                    Array[i, j] = value;
            }
            get
            {
                if (i >= 0 && j >= 0 && i < N && j < N)
                    return Array[i, j];
                else return Array[0, 0];
            }
        }
        //реализация аритметическии операции
        public static Matrix operator +(Matrix A, Matrix B)
        {
            if (A == null || B == null || A.N != B.N)
                return new Matrix(2);
            Matrix C = new Matrix(A.N);
            for (int i = 0; i < C.N; i++)
                for (int j = 0; j < C.N; j++)
                    C[i, j] = A[i, j] + B[i, j];
            return C;


        }
        public static Matrix operator *(Matrix A, Matrix B)
        {
            if (A == null || B == null || A.N != B.N)
                return new Matrix(2);
            Matrix C = new Matrix(A.N);
            for (int i = 0; i < C.N; i++)
                for (int j = 0; j < C.N; j++)
                {
                    C[i, j] = 0.0;
                    for (int k = 0; k < C.N; k++)
                        C[i, j] += A[i, j] * B[i, j];
                }
            return C;
        }
        //методы для варианта 13
        public static Matrix getA(int k)
        {
            k = Math.Max(2, k);
            Matrix A = new Matrix(k);
            for (int i = 0; i < A.N; i++)
                for (int j = 0; j < A.N; j++)
                    if (j == 0)
                        A[i, j] = k - i - 1;
                    else if (i == j)
                        A[i, j] = k;
                    else
                        A[i, j] = 0.0;
            return A;
        }
        public static Matrix getB(Matrix A, int k)
        {
            if (A == null || A.N == 0)
                return new Matrix(2);
            Matrix B = new Matrix(A.N);
            Random rnd = new Random();

            for (int i = 0; i < B.N; i++)
            {
                for (int j = 0; j < B.N; j++)
                {
                    if (i == k || j == k)
                        B[i, j] = rnd.NextDouble();
                    else
                        B[i, j] = A[i, j];
                }
            }
            for(int i = 0; i < B.N; i++)
            {
                if (i != k)
                    B[k, i] += k;
            }
            return B;
        }
    }
}
